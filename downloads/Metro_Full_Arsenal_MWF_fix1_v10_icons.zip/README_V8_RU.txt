Metro Full Arsenal v8 — 25 отдельных оружий.
Заменить прежний пак, не ставить рядом. MWF fix1-metro4 на клиенте и сервере.
Перед обновлением заменить личные обвесы Убойника на общие и сохранить резервную копию мира:
metro_uboinik_laser -> metro_mod_laser
metro_uboinik_suppressor -> metro_mod_glushak
metro_mod_uboinik_barrel -> metro_mod_barrel
metro_uboinik_collimator -> metro_mod_kolimator
Мини-огнемёт — отдельный ID, пока bullet-based MWF адаптация, НЕ поток огня.
Медведь: начальный профиль Убойника; исходные пневматические механики не добавлены.
Модели, руки и крепления требуют проверки в игре. Minecraft здесь не запускался.
