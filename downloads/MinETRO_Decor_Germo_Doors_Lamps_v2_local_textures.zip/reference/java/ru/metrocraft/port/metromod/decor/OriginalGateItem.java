package ru.metrocraft.port.metromod.decor;

import net.minecraft.block.state.IBlockState;
import net.minecraft.entity.player.EntityPlayer;
import net.minecraft.item.ItemBlock;
import net.minecraft.item.ItemStack;
import net.minecraft.util.*;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.text.TextComponentTranslation;
import net.minecraft.world.World;
import java.util.List;
import java.util.UUID;

/** Validate the whole structure BEFORE changing any cell or consuming an item. */
public final class OriginalGateItem extends ItemBlock {
    private final OriginalGateBlock gate;
    public OriginalGateItem(OriginalGateBlock gate) { super(gate); this.gate = gate; setMaxStackSize(1); }
    @Override public EnumActionResult onItemUse(EntityPlayer player, World world, BlockPos clicked, EnumHand hand,
                                               EnumFacing face, float hitX, float hitY, float hitZ) {
        BlockPos origin = world.getBlockState(clicked).getBlock().isReplaceable(world, clicked) ? clicked : clicked.offset(face);
        // A wall switch faces OUT of the clicked wall, independent of player yaw.
        if(gate.profile.is("Lever") && (face.getAxis().isVertical() || !world.getBlockState(clicked).isSideSolid(world,clicked,face)))return EnumActionResult.FAIL;
        EnumFacing facing = gate.profile.is("Lever")?face:player.getHorizontalFacing().getOpposite();
        ItemStack stack = player.getHeldItem(hand);
        if (stack.isEmpty() || player.isSpectator() || world.restoringBlockSnapshots) return EnumActionResult.FAIL;
        List<BlockPos> footprint = gate.profile.occupied(origin, facing, 0);
        for (BlockPos pos : footprint) {
            if (!world.isBlockLoaded(pos) || pos.getY() < 0 || pos.getY() >= world.getHeight()
                    || !world.getWorldBorder().contains(pos) || !world.isAirBlock(pos)
                    || !player.canPlayerEdit(pos, face, stack)
                    || !world.isBlockModifiable(player, pos)) {
                if (!world.isRemote) player.sendStatusMessage(new TextComponentTranslation("metroport.gate.obstructed"), true);
                return EnumActionResult.FAIL;
            }
        }
        // No building a closed gate through another player/mob.
        for (net.minecraft.util.math.AxisAlignedBB box : gate.profile.initialPhysics(origin,facing,0))
            if (!world.checkNoEntityCollision(box)) return EnumActionResult.FAIL;
        if (world.isRemote) return EnumActionResult.SUCCESS;
        UUID owner = UUID.randomUUID();
        java.util.Map<BlockPos, IBlockState> changed = new java.util.LinkedHashMap<>();
        boolean installed = false;
        try {
            for (BlockPos pos : footprint) {
                changed.put(pos, world.getBlockState(pos));
                boolean root = pos.equals(origin);
                if (!world.setBlockState(pos, root ? gate.getDefaultState().withProperty(OriginalGateBlock.FACING, facing)
                        : OriginalGates.PART.getDefaultState(), 3)) return EnumActionResult.FAIL;
                if (root) {
                    OriginalGateTile tile = (OriginalGateTile) world.getTileEntity(pos);
                    tile.configure(owner, gate.profile, facing);
                } else {
                    ((OriginalGatePartTile) world.getTileEntity(pos)).configure(origin, owner);
                }
            }
            OriginalGateTile tile = (OriginalGateTile) world.getTileEntity(origin);
            if (tile.blockedAt(tile.progress)) return EnumActionResult.FAIL;
            tile.ready = true; tile.markDirty();
            if (!world.captureBlockSnapshots) tile.syncStructure();
            installed = true;
        } finally {
            // Roll back OUR cells only. Never clear or replace someone else's block.
            if (!installed) {
                OriginalGateTile root = OriginalGates.controller(world, origin);
                if (root != null && owner.equals(root.owner)) root.removing = true;
            }
            if (!installed) for (java.util.Map.Entry<BlockPos,IBlockState> entry : changed.entrySet()) {
                net.minecraft.tileentity.TileEntity te = world.getTileEntity(entry.getKey());
                if ((te instanceof OriginalGateTile && owner.equals(((OriginalGateTile) te).owner))
                        || (te instanceof OriginalGatePartTile && owner.equals(((OriginalGatePartTile) te).owner)))
                    world.setBlockState(entry.getKey(), entry.getValue(), 2);
            }
        }
        if (!player.capabilities.isCreativeMode) stack.shrink(1);
        return EnumActionResult.SUCCESS;
    }
}
