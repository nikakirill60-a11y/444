package ru.metrocraft.port.metromod.decor;

import net.minecraft.nbt.NBTTagCompound;
import net.minecraft.network.NetworkManager;
import net.minecraft.network.play.server.SPacketUpdateTileEntity;
import net.minecraft.tileentity.TileEntity;
import net.minecraft.util.math.BlockPos;
import java.util.UUID;

/** Persistent ownership, not a guess based on neighbouring air/block types. */
public final class OriginalGatePartTile extends TileEntity {
    public BlockPos origin = BlockPos.ORIGIN;
    public UUID owner;
    public void configure(BlockPos pos, UUID owner) { this.origin = pos.toImmutable(); this.owner = owner; markDirty(); sync(); }
    public void sync() {
        if(world==null || world.isRemote || world.captureBlockSnapshots)return;
        net.minecraft.block.state.IBlockState state=world.getBlockState(getPos());
        world.notifyBlockUpdate(getPos(),state,state,2);
    }
    public OriginalGateTile controller() {
        if (world == null || owner == null || !world.isBlockLoaded(origin)) return null;
        TileEntity tile = world.getTileEntity(origin);
        return tile instanceof OriginalGateTile && owner.equals(((OriginalGateTile) tile).owner) ? (OriginalGateTile) tile : null;
    }
    @Override public NBTTagCompound writeToNBT(NBTTagCompound tag) {
        super.writeToNBT(tag); tag.setLong("Origin", origin.toLong());
        if (owner != null) tag.setUniqueId("Owner", owner); return tag;
    }
    @Override public void readFromNBT(NBTTagCompound tag) {
        super.readFromNBT(tag); origin = BlockPos.fromLong(tag.getLong("Origin"));
        owner = tag.hasUniqueId("Owner") ? tag.getUniqueId("Owner") : null;
    }
    @Override public NBTTagCompound getUpdateTag() { return writeToNBT(new NBTTagCompound()); }
    @Override public SPacketUpdateTileEntity getUpdatePacket() { return new SPacketUpdateTileEntity(pos, 0, getUpdateTag()); }
    @Override public void onDataPacket(NetworkManager manager, SPacketUpdateTileEntity packet) { readFromNBT(packet.getNbtCompound()); }
}
